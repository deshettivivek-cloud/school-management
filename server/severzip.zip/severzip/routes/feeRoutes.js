const validate = require('../middleware/validate');
const { recordPaymentSchema } = require('../validators/moneySchemas');
const express = require('express');
const router = express.Router();
const {
  getFeeStructures,
  createFeeStructure,
  updateFeeStructure,
  deleteFeeStructure,
  applyFeeToStudents,
} = require('../controllers/feeStructureController');
const {
  getFeeCollections,
  getStudentFeeCollection,
  getStudentFeeHistory,
  commitFee,
  recordPayment,
  getPendingFees,
  getFeeStats,
  getReceipt,
  sendFeeReminders
} = require('../controllers/feeCollectionController');
const { protect } = require('../middleware/auth');
const { roleCheck } = require('../middleware/roleCheck');

// Fee Structure routes
router.get('/structure', protect, getFeeStructures);
router.post('/structure', protect, roleCheck('principal'), createFeeStructure);
router.put('/structure/:id', protect, roleCheck('principal'), updateFeeStructure);
router.delete('/structure/:id', protect, roleCheck('principal'), deleteFeeStructure);
router.post('/structure/:id/apply', protect, roleCheck('principal', 'clerk'), applyFeeToStudents);

// Fee Collection routes
router.get('/collection', protect, getFeeCollections);
router.get('/collection/:studentId', protect, getStudentFeeCollection);
router.get('/history/:studentId', protect, getStudentFeeHistory);
router.post('/collection/commit', protect, roleCheck('principal', 'clerk'), commitFee);
router.post('/collection/pay', protect, validate(recordPaymentSchema), recordPayment);
router.post('/collection/reminders', protect, sendFeeReminders);
router.post('/send-sms-receipt', protect, require('../controllers/feeCollectionController').sendSmsReceipt);
router.post('/send-whatsapp-receipt', protect, require('../controllers/feeCollectionController').sendWhatsappReceipt);

// Pending fees
router.get('/pending', protect, getPendingFees);

// Stats
router.get('/stats', protect, getFeeStats);

// Receipt
router.get('/receipt/:collectionId/:paymentId', protect, getReceipt);

module.exports = router;
